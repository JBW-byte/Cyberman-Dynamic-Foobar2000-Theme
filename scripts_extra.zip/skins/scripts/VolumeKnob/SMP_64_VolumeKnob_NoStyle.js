'use strict';
		  // ======= AUTHOR L.E.D. (AI-assisted) ========\\
		 // ========  SMP 64bit Volume Knob V2.4  ========\\
		// =========== Simple Function + Themes ===========\\

 // ===================*** Foobar2000 64bit ***================== \\
// ======= For Spider Monekey Panel 64bit, author: marc2003 ====== \\

window.DrawMode = 0; // 0 - default GDI+ mode. 1 - D2D

window.DefineScript('SMP 64bit Volume Knob V2.4', { author: 'L.E.D.', options: { grab_focus: true } });

// ====================== HELPER INCLUDES ======================
// Lodash first (needed for helpers.js if it uses _)
include(fb.ComponentPath + 'samples\\complete\\js\\lodash.min.js');
include(fb.ComponentPath + 'samples\\complete\\js\\helpers.js');
include(fb.ComponentPath + 'samples\\complete\\js\\panel.js');

// Panel for DUI/CUI background
const panel = new _panel(false);

// ====================== KEYBOARD INPUT ======================
window.DlgCode = DLGC_WANTALLKEYS;

// ====================== PROPERTIES ======================
const props = { currentTheme: new _p('VolumeKnob.Theme', 0) };

// ====================== CONFIG ======================
const CONFIG = Object.freeze({
    DRAG_SCALE: 0.5,
    WHEEL_STEP_DEG: (420 - 120) / (21 - 1) / 2, // half a marker: SWEEP_TOTAL/(TICK_COUNT-1)/2 = 7.5°
    SNAP_ENABLED: true,
    SNAP_TOLERANCE_DB: 0.5,
    PADDING: 20,

    DRAG_FOLLOW_SPEED: 1.0,
    RELEASE_EASING: 0.18,
    ANGLE_EPSILON: 0.05,
    ANIMATION_INTERVAL: Math.floor(1000 / 60),

    ANGLE_MIN: 120,
    ANGLE_MAX: 420,
    TICK_COUNT: 21,
    ROTATION_OFFSET: -270,

    INNER_RATIO: 0.92,
    TICK_LENGTH_RATIO: 0.04,
    MARKER_START_RATIO: 0.225,
    MARKER_END_RATIO: 0.45,
    MARKER_SEGMENTS: 10,
    MARKER_WIDTH_RATIO: 0.015,

    VOL_BREAKPOINT_1: 25,
    VOL_BREAKPOINT_2: 50,
    DB_BREAKPOINT_1: -20,
    DB_BREAKPOINT_2: -8.5
});

// ====================== PRE-CALCULATED CONSTANTS ======================
const SWEEP_TOTAL = CONFIG.ANGLE_MAX - CONFIG.ANGLE_MIN;
const SWEEP_HALF = SWEEP_TOTAL / 2;
const DEG2RAD = Math.PI / 180;

// Precompute volume slopes for fast uiToDb / dbToUi
const VOL_SLOPE_1 = 80 / CONFIG.VOL_BREAKPOINT_1;
const VOL_SLOPE_2 = (CONFIG.DB_BREAKPOINT_2 - CONFIG.DB_BREAKPOINT_1) / CONFIG.VOL_BREAKPOINT_1;
const VOL_SLOPE_3 = Math.abs(CONFIG.DB_BREAKPOINT_2) / (100 - CONFIG.VOL_BREAKPOINT_2);
// uiToAngle divides the second half by VOL_RANGE_2 = (100 - VOL_BREAKPOINT_2)
const VOL_RANGE_2 = 100 - CONFIG.VOL_BREAKPOINT_2;

// ====================== THEMES ======================
const THEMES = [
    { name: "Classic Gray", knob: _RGB(80,80,80), inner: _RGB(50,50,50), tick: _RGB(160,160,160), marker: _RGB(255,180,180) },
    { name: "Warm Amber", knob: _RGB(90,70,50), inner: _RGB(60,45,30), tick: _RGB(200,160,100), marker: _RGB(255,200,120) },
    { name: "Cool Blue", knob: _RGB(60,70,90), inner: _RGB(40,50,70), tick: _RGB(140,170,220), marker: _RGB(160,200,255) },
    { name: "Mint Green", knob: _RGB(60,90,80), inner: _RGB(40,65,55), tick: _RGB(140,200,180), marker: _RGB(160,255,220) },
    { name: "Purple Haze", knob: _RGB(85,70,95), inner: _RGB(55,45,65), tick: _RGB(190,160,220), marker: _RGB(220,180,255) },
    { name: "Fire Red", knob: _RGB(90,55,55), inner: _RGB(60,35,35), tick: _RGB(220,150,150), marker: _RGB(255,170,170) },
    { name: "Mono Dark", knob: _RGB(50,50,50), inner: _RGB(30,30,30), tick: _RGB(120,120,120), marker: _RGB(200,200,200) },
    { name: "Ocean Teal", knob: _RGB(40,80,85), inner: _RGB(25,55,60), tick: _RGB(120,190,200), marker: _RGB(140,230,240) },
    { name: "Gold Brass", knob: _RGB(95,85,50), inner: _RGB(70,60,35), tick: _RGB(230,210,150), marker: _RGB(255,235,180) },
    { name: "Neon Pink", knob: _RGB(90,50,70), inner: _RGB(65,35,50), tick: _RGB(230,150,200), marker: _RGB(255,170,220) }
];

THEMES.forEach(t => {
    t._r = (t.marker >>> 16) & 0xFF;
    t._g = (t.marker >>>  8) & 0xFF;
    t._b =  t.marker         & 0xFF;
});

const _clampedTheme = Math.max(0, Math.min(THEMES.length - 1, props.currentTheme.value));
if (_clampedTheme !== props.currentTheme.value) props.currentTheme.value = _clampedTheme;

// ====================== STATE MANAGEMENT ======================
const State = {
    dragging: false,
    lastY: 0,
    uiVolume: 50,
    currentAngle: 0,
    targetAngle: 0,
    dragTargetAngle: 0,
    animationTimer: null,
    muteResyncTimer: null,
    needsRepaint: false,
    hasIsMuted: false,
    geometryCache: {
        valid: false,
        width: 0,
        height: 0,
        cx: 0,
        cy: 0,
        size: 0,
        x: 0,
        y: 0,
        radius: 0,
        innerSize: 0,
        tickLength: 0,
        tickAngles: [],
        markerSegments: []
    },

    updateGeometryCache(w,h) {
        const cache = this.geometryCache;
        if(cache.valid && cache.width===w && cache.height===h) return;

        cache.width = w;
        cache.height = h;
        cache.cx = w/2;
        cache.cy = h/2;
        cache.size = Math.min(w,h)-CONFIG.PADDING*2;
        cache.x = cache.cx - cache.size/2;
        cache.y = cache.cy - cache.size/2;
        cache.radius = cache.size*0.5;
        cache.innerSize = cache.size*CONFIG.INNER_RATIO;
        cache.tickLength = cache.size*CONFIG.TICK_LENGTH_RATIO;

        // Precompute tick angles
        cache.tickAngles = [];
        for(let i=0;i<CONFIG.TICK_COUNT;i++){
            cache.tickAngles[i] = (CONFIG.ANGLE_MIN + i/(CONFIG.TICK_COUNT-1)*SWEEP_TOTAL + CONFIG.ROTATION_OFFSET) * DEG2RAD;
        }

        // Precompute marker segments
        cache.markerSegments = [];
        const segRange = CONFIG.MARKER_END_RATIO - CONFIG.MARKER_START_RATIO;
        for(let s=0;s<CONFIG.MARKER_SEGMENTS;s++){
            cache.markerSegments[s] = {
                t0: CONFIG.MARKER_START_RATIO + s/CONFIG.MARKER_SEGMENTS*segRange,
                t1: CONFIG.MARKER_START_RATIO + (s+1)/CONFIG.MARKER_SEGMENTS*segRange
            };
        }

        cache.valid=true;
    },

    invalidateGeometry(){ this.geometryCache.valid=false; },

    cleanup(){
        this.stopAnimation();
        if (this.muteResyncTimer) { window.ClearTimeout(this.muteResyncTimer); this.muteResyncTimer = null; }
        this.geometryCache.tickAngles=null;
        this.geometryCache.markerSegments=null;
    },

    stopAnimation() {
        if (this.animationTimer) { window.ClearInterval(this.animationTimer); this.animationTimer = null; }
    },

    startAnimation() {
        if (this.animationTimer) return;
        this.animationTimer = window.SetInterval(() => {
            const settled = Math.abs(this.currentAngle - this.targetAngle) < CONFIG.ANGLE_EPSILON;
            if (this.needsRepaint || !settled) {
                window.Repaint();
                this.needsRepaint = false;
            } else {
                this.stopAnimation();  // idle — nothing to animate or repaint
            }
        }, CONFIG.ANIMATION_INTERVAL);
    },

    requestRepaint() {
        this.needsRepaint = true;
        this.startAnimation();
    }
};

// ====================== UTILITIES ======================
const Utils = {
    clamp(value,min,max){ return Math.max(min, Math.min(max,value)); },
    roundTo(value,decimals){ const m=Math.pow(10,decimals); return Math.round(value*m)/m; }
};

// ====================== VOLUME CONVERSION ======================
const VolumeConverter = {
    uiToDb(v){
        if(v<=CONFIG.VOL_BREAKPOINT_1) return -100 + v*VOL_SLOPE_1;
        if(v<=CONFIG.VOL_BREAKPOINT_2) return CONFIG.DB_BREAKPOINT_1 + (v-CONFIG.VOL_BREAKPOINT_1)*VOL_SLOPE_2;
        return CONFIG.DB_BREAKPOINT_2 + (v-CONFIG.VOL_BREAKPOINT_2)*VOL_SLOPE_3;
    },
    dbToUi(db){
        db = Utils.clamp(db, -100, 0);
        if(db<=CONFIG.DB_BREAKPOINT_1) return (db+100)/VOL_SLOPE_1;
        if(db<=CONFIG.DB_BREAKPOINT_2) return CONFIG.VOL_BREAKPOINT_1 + (db-CONFIG.DB_BREAKPOINT_1)/VOL_SLOPE_2;
        return CONFIG.VOL_BREAKPOINT_2 + (db-CONFIG.DB_BREAKPOINT_2)/VOL_SLOPE_3;
    },
    uiToAngle(v) {
        if (v <= CONFIG.VOL_BREAKPOINT_2)
            return CONFIG.ANGLE_MIN + (v / CONFIG.VOL_BREAKPOINT_2) * SWEEP_HALF;
        return CONFIG.ANGLE_MIN + SWEEP_HALF + ((v - CONFIG.VOL_BREAKPOINT_2) / VOL_RANGE_2) * SWEEP_HALF;
    },
    // Inverse of uiToAngle — needed by handleWheel to step in degree-space
    angleToUi(angle) {
        const mid = CONFIG.ANGLE_MIN + SWEEP_HALF;
        if (angle <= mid)
            return (angle - CONFIG.ANGLE_MIN) / SWEEP_HALF * CONFIG.VOL_BREAKPOINT_2;
        return CONFIG.VOL_BREAKPOINT_2 + (angle - mid) / SWEEP_HALF * VOL_RANGE_2;
    },
    applySnap(db){ if(!CONFIG.SNAP_ENABLED||State.dragging) return db; if(Math.abs(db)<=CONFIG.SNAP_TOLERANCE_DB) return 0; if(Math.abs(db+10)<=CONFIG.SNAP_TOLERANCE_DB) return -10; return db; }
};

// ====================== VOLUME SYNC ======================
const VolumeSync = {
    syncFromFoobar(){
        try{
            const fbVol=Utils.clamp(fb.Volume,-100,0);
            State.uiVolume=VolumeConverter.dbToUi(fbVol);
            State.targetAngle=State.dragTargetAngle=VolumeConverter.uiToAngle(State.uiVolume);
            State.currentAngle=State.targetAngle;
            State.requestRepaint();
        }catch(e){ if(typeof console!=="undefined")console.log("Error syncing from foobar:",e); }
    },
    setFoobarVolume(uiVol, skipSnap){
        try{
            const db = VolumeConverter.uiToDb(uiVol);
            const newDb = skipSnap ? db : VolumeConverter.applySnap(db);
            if(Math.abs(newDb-fb.Volume)>=0.1) fb.Volume=newDb;
        }catch(e){ if(typeof console!=="undefined")console.log("Error setting foobar volume:",e); }
    }
};

// ====================== RENDERER ======================
const Renderer = {
    draw(gr){
        const w=window.Width,h=window.Height;
        if(!w||!h) return;
        State.updateGeometryCache(w,h);
        const cache=State.geometryCache,theme=THEMES[props.currentTheme.value];
        // FIX: guard against null arrays after State.cleanup() — a final on_paint
        // may fire after on_script_unload has nulled tickAngles/markerSegments.
        if (!cache.tickAngles || !cache.markerSegments) return;

        // FIX Bug15: run animation update before the paint try/catch so errors in
        // updateAnimation() are not silently swallowed by the paint error handler.
        this.updateAnimation();

        try{
            // Outer circle
            gr.FillEllipse(cache.x,cache.y,cache.size,cache.size,theme.knob);

            // Inner circle
            const innerX=cache.cx-cache.innerSize/2,innerY=cache.cy-cache.innerSize/2;
            gr.FillEllipse(innerX,innerY,cache.innerSize,cache.innerSize,theme.inner);

            // Ticks
            for(let i=0;i<CONFIG.TICK_COUNT;i++){
                const a=cache.tickAngles[i],sa=Math.sin(a),ca=Math.cos(a);
                gr.DrawLine(
                    cache.cx+sa*(cache.radius-cache.tickLength),
                    cache.cy-ca*(cache.radius-cache.tickLength),
                    cache.cx+sa*cache.radius,
                    cache.cy-ca*cache.radius,
                    2,
                    theme.tick
                );
            }

            // Marker
            const rad=(State.currentAngle+CONFIG.ROTATION_OFFSET)*DEG2RAD;
            const sr=Math.sin(rad),cr=Math.cos(rad);
            let alpha=255;
            if(State.hasIsMuted){
                try{ if(fb.IsMuted) alpha=90; }catch(e){}
            }
            const { _r: r, _g: g, _b: b } = theme;
            const wMarker = Math.max(1, cache.size * CONFIG.MARKER_WIDTH_RATIO);
            const markerCol = _RGBA(r, g, b, alpha);
            for(let s=0;s<CONFIG.MARKER_SEGMENTS;s++){
                const seg=cache.markerSegments[s];
                gr.DrawLine(
                    cache.cx+sr*cache.size*seg.t0,
                    cache.cy-cr*cache.size*seg.t0,
                    cache.cx+sr*cache.size*seg.t1,
                    cache.cy-cr*cache.size*seg.t1,
                    wMarker,
                    markerCol
                );
            }

        }catch(e){ if(typeof console!=="undefined")console.log("Paint error:",e); }
    },
    updateAnimation(){
        const prev=State.currentAngle;
        if(State.dragging) State.currentAngle+=(State.dragTargetAngle-State.currentAngle)*CONFIG.DRAG_FOLLOW_SPEED;
        else State.currentAngle+=(State.targetAngle-State.currentAngle)*CONFIG.RELEASE_EASING;
        if(Math.abs(State.currentAngle-State.targetAngle)<CONFIG.ANGLE_EPSILON) State.currentAngle=State.targetAngle;
        if(Math.abs(State.currentAngle-prev)>CONFIG.ANGLE_EPSILON) State.requestRepaint();
    }
};

// ====================== INPUT HANDLERS ======================
const InputHandler = {
    hitTest(x,y){ const c=State.geometryCache; return c.valid&&(x-c.cx)**2+(y-c.cy)**2<=c.radius**2; },
    handleDragStart(x,y){ if(!this.hitTest(x,y)) return false; State.dragging=true; State.lastY=y; return true; },
    handleDragEnd(){ if(!State.dragging) return false; State.dragging=false; State.targetAngle=State.dragTargetAngle; State.requestRepaint(); return true; },
    handleDragMove(x,y){
        if(!State.dragging) return false;
        let v=State.uiVolume+(State.lastY-y)*CONFIG.DRAG_SCALE;
        v=Utils.clamp(Utils.roundTo(v,1),0,100);
        if(Math.abs(v-State.uiVolume)>=0.1){
            State.uiVolume=v; State.dragTargetAngle=State.targetAngle=VolumeConverter.uiToAngle(v);
            VolumeSync.setFoobarVolume(v); State.requestRepaint();
        }
        State.lastY=y; return true;
    },
    handleWheel(step){
        // Step in angle-space, then snap to the half-marker grid so the knob
        // visually aligns with tick marks. Snapping BEFORE converting to UI volume
        // avoids the round-trip rounding error (angle→vol→roundTo(1dp)→angle) that
        // was producing a small but visible mis-alignment.
        const rawAngle  = VolumeConverter.uiToAngle(State.uiVolume) + step * CONFIG.WHEEL_STEP_DEG;
        const snapped   = Math.round((rawAngle - CONFIG.ANGLE_MIN) / CONFIG.WHEEL_STEP_DEG)
                          * CONFIG.WHEEL_STEP_DEG + CONFIG.ANGLE_MIN;
        const newAngle  = Utils.clamp(snapped, CONFIG.ANGLE_MIN, CONFIG.ANGLE_MAX);
        const v         = Utils.clamp(VolumeConverter.angleToUi(newAngle), 0, 100);
        if(Math.abs(v-State.uiVolume)>=0.01){
            State.uiVolume=v; State.dragTargetAngle=State.targetAngle=newAngle;
            VolumeSync.setFoobarVolume(v, true); State.requestRepaint(); // skipSnap=true: grid steps must not be overridden by the snap tolerance
        }
        return true;
    },
    handleDoubleClick(x,y){
        if(!this.hitTest(x,y)) return false;
        try{
            fb.RunMainMenuCommand("Playback/Volume/Mute");
            if (State.muteResyncTimer) { window.ClearTimeout(State.muteResyncTimer); State.muteResyncTimer = null; }
            State.muteResyncTimer = window.SetTimeout(()=>{
                State.muteResyncTimer = null;
                if(!State.dragging) VolumeSync.syncFromFoobar();
            },50);
        }catch(e){if(typeof console!=="undefined")console.log("Error toggling mute:",e);}
        return true;
    }
};

// ====================== MENU MANAGER ======================
const MenuManager = {
    show(x,y){
        const menu=window.CreatePopupMenu();
        try{
            for(let i=0;i<THEMES.length;i++){
                const theme=THEMES[i];
                menu.AppendMenuItem(0,i+1,theme.name);
                if(i===props.currentTheme.value) menu.CheckMenuItem(i+1,true);
            }
            const id=menu.TrackPopupMenu(x,y);
            if(id>0){ props.currentTheme.value=id-1; State.requestRepaint(); }
        }catch(e){ if(typeof console!=="undefined")console.log("Menu error:",e); }
        return true;
    }
};

// ====================== LIFECYCLE GUARD ======================
// Prevents a callback that fires in a narrow race during panel teardown
// (e.g. on_volume_change or on_size right as on_script_unload runs) from
// resurrecting State.animationTimer via startAnimation() after cleanup() —
// that interval would then call window.Repaint() forever into a dead panel.
let _unloaded = false;

// ====================== INITIALIZATION ======================
function init(){
    // Isolated from the block below: on some hosts/older foobar2000 builds
    // reading fb.IsMuted can throw rather than simply being undefined. If that
    // check shared a try/catch with syncFromFoobar()/startAnimation(), a throw
    // here would silently skip both — leaving the knob desynced from the real
    // volume and its animation timer never started. Default to false on error;
    // the mute-dimming visual is cosmetic and safe to lose.
    try{
        State.hasIsMuted = (fb.IsMuted !== undefined);
    }catch(e){ State.hasIsMuted = false; }

    try{
        VolumeSync.syncFromFoobar();
        State.startAnimation();
    }catch(e){if(typeof console!=="undefined")console.log("Initialization error:",e);}
}
init();

// ====================== FOOBAR CALLBACKS ======================
function on_key_down(vkey) {
    if (_unloaded) return false;
    if (vkey === VK_UP) {
        InputHandler.handleWheel(1);
        return true;
    }
    if (vkey === VK_DOWN) {
        InputHandler.handleWheel(-1);
        return true;
    }
    return false;
}

function on_paint(gr){
    if (_unloaded) return;
    if (panel && panel.paint) panel.paint(gr);
    Renderer.draw(gr); 
}
function on_size(){
    if (_unloaded) return;
    if (panel && panel.size) panel.size();
    const w=window.Width,h=window.Height; 
    if(State.geometryCache.width!==w||State.geometryCache.height!==h){ 
        State.invalidateGeometry(); 
        State.requestRepaint(); 
    } 
}
function on_colours_changed(){
    if (_unloaded) return;
    if (panel && panel.colours_changed) panel.colours_changed();
    State.requestRepaint(); 
}
function on_font_changed(){ if (!_unloaded) State.requestRepaint(); }
function on_volume_change(){ if (!_unloaded && !State.dragging) VolumeSync.syncFromFoobar(); }
function on_mouse_lbtn_down(x,y){ if (_unloaded) return false; if (window.SetFocus) window.SetFocus(); return InputHandler.handleDragStart(x,y); }
function on_mouse_lbtn_up() { if (_unloaded) return false; return InputHandler.handleDragEnd(); }  // x,y unused
function on_mouse_move(x,y){ if (_unloaded) return false; return InputHandler.handleDragMove(x,y); }
function on_mouse_wheel(step){ if (_unloaded) return false; return InputHandler.handleWheel(step); }
function on_mouse_lbtn_dblclk(x,y){ if (_unloaded) return false; if (window.SetFocus) window.SetFocus(); return InputHandler.handleDoubleClick(x,y); }
function on_mouse_rbtn_up(x,y){ if (_unloaded) return false; return MenuManager.show(x,y); }
function on_script_unload(){ _unloaded = true; State.cleanup(); }

window.MinHeight = 250;
window.MinWidth  = 100;
  