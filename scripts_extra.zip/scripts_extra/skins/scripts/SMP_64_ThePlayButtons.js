'use strict';
           // ============== AUTHOR L.E.D. ============== \\
          // ==-== 	  Audio PlayBack Buttons v1.3    ==-== \\
         // ========== PlayBack and Custom Sets =========== \\

  // ===================*** Foobar2000 64bit ***================== \\
 // ======= For Spider Monkey Panel 64bit, author: marc2003 ======= \\
// ===  Developed from samples Playback Buttons, author:marc2003 === \\

window.DefineScript('Playback Buttons Pro v1.3' , {author:'L.E.D.', options:{grab_focus:false}});

include(fb.ComponentPath + 'samples\\complete\\js\\lodash.min.js');
include(fb.ComponentPath + 'samples\\complete\\js\\helpers.js');
include(fb.ComponentPath + 'samples\\complete\\js\\panel.js');

// ====================== CONSTANTS ======================
const MENU_ID = {
	ALIGN_V_TOP:    10,
	ALIGN_V_MIDDLE: 11,
	ALIGN_V_BOTTOM: 12,
	SIZE_SMALL:     20,
	SIZE_MEDIUM:    21,
	SIZE_LARGE:     22,
	SIZE_XL:        23,
	SIZE_CUSTOM:    24,
	PAD_GAP_CUSTOM:    30,
	PAD_BORDER_CUSTOM: 31,
	MODE_FIXED:      40,
	MODE_FILL:       41,
	MODE_FIT_HEIGHT: 42,
	COLOR_TOGGLE:   50,
	COLOR_NORMAL:   51,
	COLOR_HOVER:    52,
	COLOR_DOWN:     53,
	BG_TOGGLE:      54,
	BG_COLOR:       55,
	ALIGN_H_LEFT:   60,
	ALIGN_H_CENTER: 61,
	ALIGN_H_RIGHT:  62,
	RESET:          99
};

// Dynamic "Button Style" submenu entries start at this ID and count upward,
// one per detected style folder (including the built-in "Default" entry).
const STYLE_MENU_ID_BASE = 100;

const SIZE_PRESETS = {
	SMALL:  32,
	MEDIUM: 64,
	LARGE:  128,
	XL:     256
};

// Size/layout mode. MODE_FIXED keeps both dimensions equal to Button Size.
// MODE_FILL_WIDTH stretches width to fill the panel (fixed height). MODE_FIT_HEIGHT
// stretches height to fill the panel (fixed width). Values correspond directly
// to MENU_ID.MODE_FIXED/MODE_FILL/MODE_FIT_HEIGHT via (MENU_ID.MODE_FIXED + sizeMode).
const SIZE_MODE = {
	FIXED:      0,
	FILL_WIDTH: 1,
	FIT_HEIGHT: 2
};

const ALIGN = {
	TOP:    0,
	MIDDLE: 1,
	BOTTOM: 2,
	LEFT:   0,
	CENTER: 1,
	RIGHT:  2
};

// Default property values defined in one place so reset uses them too.
const PROP_DEFAULTS = {
	btnSize:  128,
	paddingGap:    0,   // gap between adjacent buttons
	paddingBorder: 0,   // outer padding between the buttons and the panel edge
	alignV:   1,
	alignH:   1,
	sizeMode: SIZE_MODE.FILL_WIDTH,   // preserves the previous default (Fill Width)
	useTint:     false,
	colorNormal: _RGB(255, 255, 255),
	colorHover:  _RGB(150, 150, 150),
	colorDown:   _RGB(100, 100, 100),
	useBgColor:  false,
	bgColor:     _RGB(20, 20, 20),
	buttonStyle: ''   // '' = Default (root buttons folder)
};

// ====================== BUTTON STYLE (ICON SET) SCANNING ======================
// Icon sets live as subfolders of the root buttons folder, each containing a
// full matching set of button images. The root folder itself is always the
// "Default" style (empty string).
//
// helpers.js's _img() tries the literal string first (_isFile(value)) and only
// falls back to folders.images + value if that fails. Depending on the SMP
// host's current working directory, either form can be the one that actually
// resolves — so to find the real base folder we mirror that exact check
// against the known default icon (stop) rather than assuming one form.

// NOTE on .svg: confirmed NOT supported here. foo_svg_services (reupen/svg-services)
// only exposes a native C++ service API (fb2k::std_api_try_get<svg_services::svg_services>,
// service_base, FB2K_MAKE_SERVICE_INTERFACE) for OTHER COMPILED foobar2000 components
// to consume directly — it does not patch gdi.Image()/GDI+, and Spider Monkey Panel's
// documented JS API (gdi/utils/etc.) has no binding that wraps it. There is no way for
// plain SMP script code to reach this API, so .svg files can never be loaded here
// regardless of whether the component is installed. Only real raster formats are
// probed/supported below; SVGs would need to be pre-rasterized to one of these formats.
function _resolveButtonsBaseDir() {
	// Extensions aren't known yet at this point (SUPPORTED_EXTENSIONS is defined
	// below), so probe the common ones directly here.
	const probeExts = ['.png', '.jpg', '.jpeg', '.bmp', '.gif'];
	const relBase = 'profile\\buttons\\';
	for (let i = 0; i < probeExts.length; i++) {
		if (_isFile(relBase + 'stop' + probeExts[i])) return relBase;
	}
	const imgBase = folders.images + relBase;
	for (let i = 0; i < probeExts.length; i++) {
		if (_isFile(imgBase + 'stop' + probeExts[i])) return imgBase;
	}
	// Couldn't confirm either — fall back to the folders.images form so
	// existing behaviour (and any error) matches what _img() would have done.
	return imgBase;
}

const BUTTONS_BASE_DIR = _resolveButtonsBaseDir();

// Raster formats GDI+ (gdi.Image) can natively decode. See the note above on
// why .svg is intentionally excluded.
const SUPPORTED_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.bmp', '.gif'];

// Base names (no extension) — 'pause' is intentionally NOT required here;
// getButtonImagePath() already falls back to the Default set's pause icon
// for any style folder that omits it, so requiring it would wrongly exclude
// otherwise-valid style sets.
const REQUIRED_ICON_NAMES = ['stop', 'play', 'previous', 'next'];

// Returns the first supported extension for which baseDir+baseName+ext
// exists on disk, or null if none of them do.
function _findIconExt(baseDir, baseName) {
	for (let i = 0; i < SUPPORTED_EXTENSIONS.length; i++) {
		const ext = SUPPORTED_EXTENSIONS[i];
		if (_isFile(baseDir + baseName + ext)) return ext;
	}
	return null;
}

// Scans BUTTONS_BASE_DIR for immediate subfolders that contain every name in
// REQUIRED_ICON_NAMES (any supported extension). Returns an array of style
// names; '' (Default) is always first, followed by matching subfolder names
// sorted alphabetically.
function scanButtonStyles() {
	const styles = [''];
	try {
		const fso = new ActiveXObject('Scripting.FileSystemObject');
		if (fso.FolderExists(BUTTONS_BASE_DIR)) {
			const folder = fso.GetFolder(BUTTONS_BASE_DIR);
			const en = new Enumerator(folder.SubFolders);
			for (; !en.atEnd(); en.moveNext()) {
				const sub     = en.item();
				const subPath = sub.Path + '\\';
				const hasAll  = REQUIRED_ICON_NAMES.every((name) => _findIconExt(subPath, name) !== null);
				if (hasAll) styles.push(sub.Name);
			}
		}
	} catch (e) {
		if (typeof console !== 'undefined' && console.log) {
			console.log('ThePlayButtons: scanButtonStyles error:', e);
		}
	}
	if (typeof console !== 'undefined' && console.log) {
		console.log('ThePlayButtons: scanning "' + BUTTONS_BASE_DIR + '" (required: ' +
		    REQUIRED_ICON_NAMES.join(', ') + ' — any of ' + SUPPORTED_EXTENSIONS.join('/') +
		    ') — found ' + (styles.length - 1) + ' extra style folder(s): ' + styles.slice(1).join(', '));
	}
	styles.sort((a, b) => {
		if (a === b) return 0;
		if (a === '') return -1;
		if (b === '') return 1;
		return a.localeCompare(b);
	});
	return styles;
}

// Falls back to the default style if the saved style folder no longer exists
// or no longer contains a complete matching icon set.
function validateStyle(val) {
	if (typeof val !== 'string' || val === '') return PROP_DEFAULTS.buttonStyle;
	const available = scanButtonStyles();
	return available.indexOf(val) !== -1 ? val : PROP_DEFAULTS.buttonStyle;
}

// Resolves the relative image path (as consumed by helpers.js's _img()) for a
// given icon base name (e.g. 'stop', 'play', 'pause') under the currently
// selected style, trying every supported extension. Falls back to the
// Default set's file (any supported extension) if the selected style is
// missing that specific icon.
function getButtonImagePath(baseName) {
	if (buttonStyle) {
		const styleDir = BUTTONS_BASE_DIR + buttonStyle + '\\';
		const ext = _findIconExt(styleDir, baseName);
		if (ext) return 'profile\\buttons\\' + buttonStyle + '\\' + baseName + ext;
	}
	const defExt = _findIconExt(BUTTONS_BASE_DIR, baseName) || '.png';
	return 'profile\\buttons\\' + baseName + defExt;
}

// Creates a _button, trying the resolved icon path first. If loading throws
// for any reason (corrupt file, permissions, unsupported format snuck through
// the extension check, etc.), falls back to the Default set's icon for that
// base name — resolved via _findIconExt() rather than assuming .png, since
// the Default set might use .jpg/.bmp/.gif instead. If even that fails,
// returns a button with no icon at all rather than letting an exception
// propagate and take down the whole panel.
function _createIconButton(x, y, w, h, baseName, fn, tooltip) {
	const primaryPath = getButtonImagePath(baseName);
	try {
		return new _button(x, y, w, h, {normal: primaryPath}, fn, tooltip);
	} catch (e) {
		if (typeof console !== 'undefined' && console.log) {
			console.log('ThePlayButtons: failed to load icon "' + primaryPath +
			    '", falling back to Default icon:', e);
		}
		const fallbackExt  = _findIconExt(BUTTONS_BASE_DIR, baseName) || '.png';
		const fallbackPath = 'profile\\buttons\\' + baseName + fallbackExt;
		try {
			return new _button(x, y, w, h, {normal: fallbackPath}, fn, tooltip);
		} catch (e2) {
			if (typeof console !== 'undefined' && console.log) {
				console.log('ThePlayButtons: Default icon "' + fallbackPath +
				    '" also failed to load — rendering without an icon:', e2);
			}
			return new _button(x, y, w, h, {normal: null}, fn, tooltip);
		}
	}
}

// ====================== STATE ======================
let panel = new _panel(true);
let buttons = new _buttons();
let lastPlayState = null;

// Properties
let btnSize, paddingGap, paddingBorder, alignV, alignH, sizeMode, useTint;
let colorNormal, colorHover, colorDown;
let useBgColor, bgColor;
let buttonStyle;

// ====================== PROPERTY MANAGEMENT ======================
function validateSize(val) {
	const size = parseInt(val, 10);
	return (size >= 16 && size <= 512) ? size : PROP_DEFAULTS.btnSize;
}

// Shared validator for both padding-gap and padding-border custom values.
function validatePaddingValue(val, defaultVal) {
	const v = parseInt(val, 10);
	return (!isNaN(v) && v >= 0 && v <= 300) ? v : defaultVal;
}

function validateAlign(val, defaultVal) {
	const def = (defaultVal !== undefined) ? defaultVal : 1;
	return (val >= 0 && val <= 2) ? val : def;
}

function init_properties() {
	btnSize    = validateSize(window.GetProperty('Buttons: Size',
	                 PROP_DEFAULTS.btnSize));
	// Migrate from the old fixed-preset 'Buttons: Padding' key if the new
	// 'Buttons: Padding Gap' key hasn't been written yet.
	paddingGap    = validatePaddingValue(window.GetProperty('Buttons: Padding Gap',
	                     window.GetProperty('Buttons: Padding', PROP_DEFAULTS.paddingGap)),
	                     PROP_DEFAULTS.paddingGap);
	paddingBorder = validatePaddingValue(window.GetProperty('Buttons: Padding Border',
	                     PROP_DEFAULTS.paddingBorder), PROP_DEFAULTS.paddingBorder);
	alignV     = validateAlign(window.GetProperty(
	                 'Buttons: Vertical Alignment (0=Top, 1=Middle, 2=Bottom)',
	                 PROP_DEFAULTS.alignV), PROP_DEFAULTS.alignV);
	alignH     = validateAlign(window.GetProperty(
	                 'Buttons: Horizontal Alignment (0=Left, 1=Centre, 2=Right)',
	                 PROP_DEFAULTS.alignH), PROP_DEFAULTS.alignH);
	// Migrate from the old boolean 'Buttons: Fill Panel' key if the new
	// 'Buttons: Size Mode' key hasn't been written yet.
	sizeMode = (function() {
		const legacyFill = window.GetProperty('Buttons: Fill Panel',
		                       PROP_DEFAULTS.sizeMode === SIZE_MODE.FILL_WIDTH);
		const stored = window.GetProperty('Buttons: Size Mode',
		                   legacyFill ? SIZE_MODE.FILL_WIDTH : SIZE_MODE.FIXED);
		return (stored === SIZE_MODE.FIXED || stored === SIZE_MODE.FILL_WIDTH ||
		        stored === SIZE_MODE.FIT_HEIGHT) ? stored : PROP_DEFAULTS.sizeMode;
	})();
	useTint    = window.GetProperty('Colors: Use Tint',     PROP_DEFAULTS.useTint);
	colorNormal = window.GetProperty('Colors: Normal', PROP_DEFAULTS.colorNormal);
	colorHover  = window.GetProperty('Colors: Hover',  PROP_DEFAULTS.colorHover);
	colorDown   = window.GetProperty('Colors: Down',   PROP_DEFAULTS.colorDown);
	useBgColor  = window.GetProperty('Colors: Use Background', PROP_DEFAULTS.useBgColor);
	bgColor     = window.GetProperty('Colors: Background',     PROP_DEFAULTS.bgColor);
	buttonStyle = validateStyle(window.GetProperty('Buttons: Style', PROP_DEFAULTS.buttonStyle));
}

init_properties();

// ====================== PER-STYLE SETTINGS ======================
// Every user-adjustable setting is captured and saved under a key namespaced
// to the currently selected Button Style, so each icon set remembers its own
// size/padding/alignment/colors independently. Switching Button Style saves
// the settings just used under the style being left, then restores whatever
// was last saved for the newly selected style (or PROP_DEFAULTS if that style
// has never been configured before).
function _styleConfigKey(styleName) {
	return 'Buttons: StyleCfg.' + (styleName === '' ? '__default__' : styleName);
}

function _captureCurrentConfig() {
	return {
		btnSize, paddingGap, paddingBorder, alignV, alignH, sizeMode,
		useTint, colorNormal, colorHover, colorDown,
		useBgColor, bgColor
	};
}

function _applyConfig(cfg) {
	if (!cfg) return;
	btnSize       = validateSize(cfg.btnSize);
	paddingGap    = validatePaddingValue(cfg.paddingGap, PROP_DEFAULTS.paddingGap);
	paddingBorder = validatePaddingValue(cfg.paddingBorder, PROP_DEFAULTS.paddingBorder);
	alignV        = validateAlign(cfg.alignV, PROP_DEFAULTS.alignV);
	alignH        = validateAlign(cfg.alignH, PROP_DEFAULTS.alignH);
	sizeMode      = (cfg.sizeMode === SIZE_MODE.FIXED || cfg.sizeMode === SIZE_MODE.FILL_WIDTH ||
	                  cfg.sizeMode === SIZE_MODE.FIT_HEIGHT) ? cfg.sizeMode : PROP_DEFAULTS.sizeMode;
	useTint       = !!cfg.useTint;
	colorNormal   = (typeof cfg.colorNormal === 'number') ? (cfg.colorNormal >>> 0) : PROP_DEFAULTS.colorNormal;
	colorHover    = (typeof cfg.colorHover  === 'number') ? (cfg.colorHover  >>> 0) : PROP_DEFAULTS.colorHover;
	colorDown     = (typeof cfg.colorDown   === 'number') ? (cfg.colorDown   >>> 0) : PROP_DEFAULTS.colorDown;
	useBgColor    = !!cfg.useBgColor;
	bgColor       = (typeof cfg.bgColor === 'number') ? (cfg.bgColor >>> 0) : PROP_DEFAULTS.bgColor;
}

function saveStyleConfig(styleName) {
	try {
		window.SetProperty(_styleConfigKey(styleName), JSON.stringify(_captureCurrentConfig()));
	} catch (e) {
		if (typeof console !== 'undefined' && console.log) {
			console.log('ThePlayButtons: saveStyleConfig error:', e);
		}
	}
}

function loadStyleConfig(styleName) {
	try {
		const raw = window.GetProperty(_styleConfigKey(styleName), null);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return (parsed && typeof parsed === 'object') ? parsed : null;
	} catch (e) {
		return null;
	}
}

// Apply any previously-saved per-style config for the style resolved above,
// overriding whatever init_properties() derived from the legacy/global keys.
// If this style has never been configured before, the legacy-derived values
// (or defaults) from init_properties() are kept as-is.
(function _loadInitialStyleConfig() {
	const cfg = loadStyleConfig(buttonStyle);
	if (cfg) _applyConfig(cfg);
})();

// ====================== TINT HELPER ======================
function _tintImage(img, tintColour) {
	if (!img) return null;
	const w = img.Width;
	const h = img.Height;
	const bmp = gdi.CreateImage(w, h);
	const g   = bmp.GetGraphics();
	try {
		g.SetInterpolationMode(7);
		g.DrawImage(img, 0, 0, w, h, 0, 0, w, h, 0, 255);
		const rgb = _toRGB(tintColour);
		g.FillSolidRect(0, 0, w, h, _RGBA(rgb[0], rgb[1], rgb[2], 110));
	} finally {
		bmp.ReleaseGraphics(g);
	}
	return bmp;
}

// ====================== BUTTON DISPOSAL HELPER ======================
function _disposeButton(btn) {
	if (!btn) return;
	// FIX: must call .Dispose() on GDI image objects — setting to null only removes
	// the JS reference; the underlying native GDI bitmap remains allocated until GC
	// which in SMP's SpiderMonkey is unpredictable. Each buttons.update() call
	// leaked one pair of GDI bitmaps when tint was active.
	// btn.img is always === btn.img_normal, and btn.img_hover === btn.img_normal
	// whenever tinting is off (no per-state art configured) — dispose each
	// underlying object only once, tracked by identity, rather than relying on
	// a second Dispose() call on an already-disposed object being silently
	// swallowed by its own try/catch.
	const disposed = new Set();
	const disposeOnce = (img) => {
		if (!img || disposed.has(img) || !img.Dispose) return;
		disposed.add(img);
		try { img.Dispose(); } catch(e) {}
	};
	disposeOnce(btn.img);
	disposeOnce(btn.img_normal);
	disposeOnce(btn.img_hover);
	disposeOnce(btn.img_down);
	btn.img        = null;
	btn.img_normal = null;
	btn.img_hover  = null;
	btn.img_down   = null;
}

// ====================== BUTTON UPDATE ======================
buttons.update = () => {
	let bsW, bsH, x, y;
	const gap       = _scale(paddingGap);
	const borderPad = _scale(paddingBorder);

	// Padding Border insets the entire button-layout area from all four panel
	// edges. Everything below positions/sizes buttons within this inset rect
	// only — Padding Gap (the fixed spacing between adjacent buttons) never
	// enters into this rect and is applied completely independently further
	// down. Note that for Middle/Center alignment a symmetric inset has no
	// visible effect on position (the same is true of CSS margin around
	// centered content) — Padding Border is only visibly apparent as the gap
	// to the panel edge when a button group is anchored to that edge (Top/
	// Bottom/Left/Right alignment, or either dimension in a stretch mode).
	const availX = borderPad;
	const availY = borderPad;
	const availW = Math.max(1, panel.w - (borderPad * 2));
	const availH = Math.max(1, panel.h - (borderPad * 2));

	if (sizeMode === SIZE_MODE.FILL_WIDTH) {
		// Buttons stretch to fill the inset width; height comes from Button Size.
		bsW = Math.max(1, Math.floor((availW - (gap * 3)) / 4));
		bsH = _scale(btnSize);
		x   = availX;

		if      (alignV === ALIGN.TOP)    { y = availY; }
		else if (alignV === ALIGN.MIDDLE) { y = availY + Math.floor((availH - bsH) / 2); }
		else                              { y = availY + availH - bsH; }

	} else if (sizeMode === SIZE_MODE.FIT_HEIGHT) {
		// Buttons stretch to fill the inset height; width comes from Button Size.
		bsH = availH;
		bsW = _scale(btnSize);
		y   = availY;
		const totalW = (bsW * 4) + (gap * 3);

		if      (alignH === ALIGN.LEFT)   { x = availX; }
		else if (alignH === ALIGN.CENTER) { x = availX + Math.floor((availW - totalW) / 2); }
		else                              { x = availX + availW - totalW; }

	} else {
		// Fixed aspect mode — both dimensions come from Button Size.
		const bs    = _scale(btnSize);
		bsW = bsH   = bs;
		const totalW = (bsW * 4) + (gap * 3);

		if      (alignV === ALIGN.TOP)    { y = availY; }
		else if (alignV === ALIGN.MIDDLE) { y = availY + Math.floor((availH - bsH) / 2); }
		else                              { y = availY + availH - bsH; }

		if      (alignH === ALIGN.LEFT)   { x = availX; }
		else if (alignH === ALIGN.CENTER) { x = availX + Math.floor((availW - totalW) / 2); }
		else                              { x = availX + availW - totalW; }
	}

	if (buttons.buttons.stop) {
		_disposeButton(buttons.buttons.stop);
		_disposeButton(buttons.buttons.play);
		_disposeButton(buttons.buttons.previous);
		_disposeButton(buttons.buttons.next);
	}

	// _buttons.move() (helpers.js) tracks hover by STRING KEY, not object
	// identity: `if (this.btn == temp_btn) return this.btn;` skips re-running
	// cs('hover')/cs('normal') whenever the key is unchanged. The four button
	// objects above are being replaced with brand-new instances, so if the
	// mouse is resting motionlessly over one of them right now (e.g. playback
	// toggled via a hotkey while the cursor happens to sit on the Play button),
	// the next on_mouse_move would see the same key ('play') and wrongly skip
	// applying hover state to the NEW object — leaving it stuck showing its
	// default normal-state image (and stale tooltip text) until the mouse
	// fully leaves and re-enters. Resetting the tracked key forces the next
	// move() call to treat it as a fresh hover transition instead. Also clear
	// any tooltip text left over from the old (now-disposed) button — it may
	// be stale too (e.g. still reading "Play" after the icon just flipped to
	// "Pause"), and it won't refresh on its own until that same next move().
	buttons.btn = null;
	if (typeof _tt === 'function') _tt('');

	const isPlaying = fb.IsPlaying && !fb.IsPaused;

	buttons.buttons.stop     = _createIconButton(x,                    y, bsW, bsH,
	    'stop',
	    () => { fb.Stop(); },       'Stop');

	buttons.buttons.play     = _createIconButton(x + (bsW + gap),      y, bsW, bsH,
	    isPlaying ? 'pause' : 'play',
	    () => { fb.PlayOrPause(); }, isPlaying ? 'Pause' : 'Play');

	buttons.buttons.previous = _createIconButton(x + (bsW + gap) * 2,  y, bsW, bsH,
	    'previous',
	    () => { fb.Prev(); },       'Previous');

	buttons.buttons.next     = _createIconButton(x + (bsW + gap) * 3,  y, bsW, bsH,
	    'next',
	    () => { fb.Next(); },       'Next');

	if (useTint) {
		_.forEach(buttons.buttons, (btn) => {
			if (!btn) return;
			// FIX Bug13: apply all three colour states including colorDown (img_down).
			// Capture the pre-tint source once — img_hover is the SAME object as
			// img_normal here (no per-state art is configured for any of these four
			// buttons, so helpers.js's _button() aliases img_hover = img_normal).
			// All three tinted variants must derive from this one original asset.
			const original = btn.img_normal;
			btn.img_normal = _tintImage(original, colorNormal);
			btn.img_hover  = _tintImage(original, colorHover);
			// FIX: previously sourced from btn.img_normal AFTER it was reassigned
			// above, so colorDown got compounded on top of colorNormal instead of
			// being applied to the clean original. Also previously leaked `original`
			// itself — once all three tints exist, nothing references it anymore.
			btn.img_down   = _tintImage(original, colorDown);
			btn.img = btn.img_normal;
			if (original && original !== btn.img_normal && original.Dispose) {
				try { original.Dispose(); } catch(e) {}
			}
		});
	}

	lastPlayState = isPlaying;
};

// ====================== PLAY/PAUSE ICON SWAP ======================
// Playback starting/pausing/stopping only ever changes the Play/Pause
// button's icon and tooltip — position, size, and the other three buttons
// never change. Routing that through the full buttons.update() (as before)
// disposed and reloaded all four icons from disk and recomputed layout on
// every single play/pause toggle: unnecessary work, and it re-triggers the
// same object-identity-vs-string-key hover desync buttons.update() has to
// defend against (see the comment in there) on what is by far the most
// frequent event this panel handles. Swapping just the one button in place
// avoids both: no needless I/O/layout math, and hover state is carried over
// onto the replacement object immediately instead of being dropped and left
// to resync on the next mouse move.
function updatePlayButtonIcon() {
	const old = buttons.buttons.play;
	if (!old) { buttons.update(); return; } // not built yet — fall back to a full layout pass

	const isPlaying  = fb.IsPlaying && !fb.IsPaused;
	const wasHovered = buttons.btn === 'play';

	const fresh = _createIconButton(old.x, old.y, old.w, old.h,
	    isPlaying ? 'pause' : 'play',
	    () => { fb.PlayOrPause(); }, isPlaying ? 'Pause' : 'Play');

	if (useTint) {
		const original = fresh.img_normal;
		fresh.img_normal = _tintImage(original, colorNormal);
		fresh.img_hover  = _tintImage(original, colorHover);
		fresh.img_down   = _tintImage(original, colorDown);
		fresh.img = fresh.img_normal;
		if (original && original !== fresh.img_normal && original.Dispose) {
			try { original.Dispose(); } catch(e) {}
		}
	}

	_disposeButton(old);
	buttons.buttons.play = fresh;

	// Carry hover state over to the replacement object immediately, rather
	// than resetting buttons.btn to null and waiting on the next mouse move
	// (as buttons.update() has to, since it swaps all four buttons at once
	// and can't cheaply tell which one, if any, was hovered).
	if (wasHovered) fresh.cs('hover');

	lastPlayState = isPlaying;
}

// ====================== CALLBACKS ======================
function on_size() {
	panel.size();
	buttons.update();
}

function on_paint(gr) {
	panel.paint(gr);
	if (useBgColor) {
		gr.FillSolidRect(0, 0, panel.w, panel.h, bgColor);
	}
	buttons.paint(gr);
}

function on_playback_stop() {
	updatePlayButtonIcon();
	window.Repaint();
}

function on_playback_pause() {
	const isPaused = fb.IsPaused;
	if (lastPlayState !== !isPaused) {
		updatePlayButtonIcon();
		window.Repaint();
	}
}

function on_playback_starting() {
	if (lastPlayState !== true) {
		updatePlayButtonIcon();
		window.Repaint();
	}
}

function on_mouse_move(x, y) {
	buttons.move(x, y);
}

function on_mouse_leave() {
	buttons.leave();
}

function on_mouse_lbtn_up(x, y, mask) {
	buttons.lbtn_up(x, y, mask);
}

function on_script_unload() {
	// Dispose all button GDI images.
	if (buttons.buttons) {
		_.forEach(buttons.buttons, (btn) => { _disposeButton(btn); });
	}
	// FIX Bug9: guard _tt with typeof in case helpers.js version doesn't define it.
	if (typeof _tt === 'function') _tt('');
	// FIX Bug8: guard _gr before passing to ReleaseGraphics — _gr may be null if
	// it was never initialised or was already released.
	if (_bmp) {
		if (_gr) { try { _bmp.ReleaseGraphics(_gr); } catch(e) {} }
		try { _bmp.Dispose(); } catch(e) {}
	}
	_gr  = null;
	_bmp = null;
}

// ====================== MENU ======================
function on_mouse_rbtn_up(x, y) {
	const m   = window.CreatePopupMenu();
	const v   = window.CreatePopupMenu();
	const h   = window.CreatePopupMenu();
	const s   = window.CreatePopupMenu();
	const p   = window.CreatePopupMenu();
	const col = window.CreatePopupMenu();
	const sty = window.CreatePopupMenu();

	// Mode selection
	m.AppendMenuItem(MF_STRING, MENU_ID.MODE_FIXED,      'Fixed (Maintain Aspect)');
	m.AppendMenuItem(MF_STRING, MENU_ID.MODE_FILL,       'Fill Width (Stretch)');
	m.AppendMenuItem(MF_STRING, MENU_ID.MODE_FIT_HEIGHT, 'Fit Height (Stretch)');
	m.CheckMenuRadioItem(MENU_ID.MODE_FIXED, MENU_ID.MODE_FIT_HEIGHT,
	    MENU_ID.MODE_FIXED + sizeMode);
	m.AppendMenuSeparator();

	// Horizontal alignment (grayed in Fill Width mode — buttons span the full width)
	h.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_H_LEFT,   'Left');
	h.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_H_CENTER, 'Centre');
	h.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_H_RIGHT,  'Right');
	h.CheckMenuRadioItem(MENU_ID.ALIGN_H_LEFT, MENU_ID.ALIGN_H_RIGHT,
	    MENU_ID.ALIGN_H_LEFT + alignH);
	h.AppendTo(m, sizeMode === SIZE_MODE.FILL_WIDTH ? MF_GRAYED : MF_STRING, 'Horizontal Alignment');

	// Vertical alignment (grayed in Fit Height mode — buttons span the full height)
	v.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_V_TOP,    'Top');
	v.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_V_MIDDLE, 'Middle');
	v.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_V_BOTTOM, 'Bottom');
	v.CheckMenuRadioItem(MENU_ID.ALIGN_V_TOP, MENU_ID.ALIGN_V_BOTTOM,
	    MENU_ID.ALIGN_V_TOP + alignV);
	v.AppendTo(m, sizeMode === SIZE_MODE.FIT_HEIGHT ? MF_GRAYED : MF_STRING, 'Vertical Alignment');
	m.AppendMenuSeparator();

	// Button Style (icon set) — rescanned fresh on every menu open so newly
	// added/removed folders are picked up without a script reload.
	const stylesList = scanButtonStyles();
	stylesList.forEach((styleName, i) => {
		const label = styleName === '' ? 'Default' : styleName;
		sty.AppendMenuItem(MF_STRING, STYLE_MENU_ID_BASE + i, label);
		if (styleName === buttonStyle) sty.CheckMenuItem(STYLE_MENU_ID_BASE + i, true);
	});
	if (stylesList.length <= 1) {
		sty.AppendMenuSeparator();
		sty.AppendMenuItem(MF_GRAYED, STYLE_MENU_ID_BASE + stylesList.length,
		    'No extra icon sets found');
	}
	sty.AppendTo(m, MF_STRING, 'Button Style');

	// Button size
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_SMALL,  `Small (${SIZE_PRESETS.SMALL})`);
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_MEDIUM, `Medium (${SIZE_PRESETS.MEDIUM})`);
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_LARGE,  `Large (${SIZE_PRESETS.LARGE})`);
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_XL,     `Extra Large (${SIZE_PRESETS.XL})`);
	s.AppendMenuSeparator();
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_CUSTOM, 'Set Custom Size...');
	s.AppendTo(m, MF_STRING, 'Button Size');

	// Padding — gap between buttons, and outer border padding to the panel edge.
	p.AppendMenuItem(MF_STRING, MENU_ID.PAD_GAP_CUSTOM,    `Padding Gap: ${paddingGap}px...`);
	p.AppendMenuItem(MF_STRING, MENU_ID.PAD_BORDER_CUSTOM, `Padding Border: ${paddingBorder}px...`);
	p.AppendTo(m, MF_STRING, 'Padding');

	// Colors & Tint
	col.AppendMenuItem(MF_STRING, MENU_ID.COLOR_TOGGLE, 'Enable Custom Tint');
	col.CheckMenuItem(MENU_ID.COLOR_TOGGLE, useTint);
	col.AppendMenuSeparator();
	col.AppendMenuItem(useTint ? MF_STRING : MF_GRAYED, MENU_ID.COLOR_NORMAL, 'Set Normal Color...');
	col.AppendMenuItem(useTint ? MF_STRING : MF_GRAYED, MENU_ID.COLOR_HOVER,  'Set Hover Color...');
	col.AppendMenuItem(useTint ? MF_STRING : MF_GRAYED, MENU_ID.COLOR_DOWN,   'Set Click Color...');
	col.AppendMenuSeparator();
	col.AppendMenuItem(MF_STRING, MENU_ID.BG_TOGGLE, 'Enable Background Colour');
	col.CheckMenuItem(MENU_ID.BG_TOGGLE, useBgColor);
	col.AppendMenuItem(useBgColor ? MF_STRING : MF_GRAYED, MENU_ID.BG_COLOR, 'Set Background Color...');
	col.AppendTo(m, MF_STRING, 'Colors & Tint');

	m.AppendMenuSeparator();
	m.AppendMenuItem(MF_STRING, MENU_ID.RESET, 'Reset This Style to Defaults');

	const idx = m.TrackPopupMenu(x, y);

	// Button Style selection — handled first since its ID range is dynamic.
	if (idx >= STYLE_MENU_ID_BASE && idx < STYLE_MENU_ID_BASE + stylesList.length) {
		const selected = stylesList[idx - STYLE_MENU_ID_BASE];
		if (selected !== buttonStyle) {
			// Persist whatever was just being used under the style we're leaving,
			// then restore (or default) the settings for the newly selected style.
			saveStyleConfig(buttonStyle);
			buttonStyle = selected;
			window.SetProperty('Buttons: Style', buttonStyle);
			_applyConfig(loadStyleConfig(buttonStyle) || PROP_DEFAULTS);
			buttons.update();
			window.Repaint();
		}
		return true;
	}

	let changed = false;

	switch (idx) {
		case MENU_ID.ALIGN_V_TOP:
		case MENU_ID.ALIGN_V_MIDDLE:
		case MENU_ID.ALIGN_V_BOTTOM:
			alignV = idx - MENU_ID.ALIGN_V_TOP;
			window.SetProperty('Buttons: Vertical Alignment (0=Top, 1=Middle, 2=Bottom)', alignV);
			changed = true;
			break;

		case MENU_ID.ALIGN_H_LEFT:
		case MENU_ID.ALIGN_H_CENTER:
		case MENU_ID.ALIGN_H_RIGHT:
			if (sizeMode !== SIZE_MODE.FILL_WIDTH) {
				alignH = idx - MENU_ID.ALIGN_H_LEFT;
				window.SetProperty('Buttons: Horizontal Alignment (0=Left, 1=Centre, 2=Right)', alignH);
				changed = true;
			}
			break;

		case MENU_ID.SIZE_SMALL:
			btnSize = SIZE_PRESETS.SMALL;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_MEDIUM:
			btnSize = SIZE_PRESETS.MEDIUM;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_LARGE:
			btnSize = SIZE_PRESETS.LARGE;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_XL:
			btnSize = SIZE_PRESETS.XL;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_CUSTOM: {  // braces needed — declares local consts
			const val = utils.InputBox(window.ID,
			    'Enter button size (16-512 pixels):', 'Custom Size', btnSize);
			if (val) {
				const newSize = validateSize(val);
				if (newSize !== btnSize) {
					btnSize = newSize;
					window.SetProperty('Buttons: Size', btnSize);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.PAD_GAP_CUSTOM: {
			const val = utils.InputBox(window.ID,
			    'Enter gap between buttons (0-300 pixels):', 'Padding Gap', paddingGap);
			if (val !== undefined && val !== null && val !== '') {
				const newGap = validatePaddingValue(val, paddingGap);
				if (newGap !== paddingGap) {
					paddingGap = newGap;
					window.SetProperty('Buttons: Padding Gap', paddingGap);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.PAD_BORDER_CUSTOM: {
			const val = utils.InputBox(window.ID,
			    'Enter outer border padding to the panel edge (0-300 pixels):', 'Padding Border', paddingBorder);
			if (val !== undefined && val !== null && val !== '') {
				const newBorder = validatePaddingValue(val, paddingBorder);
				if (newBorder !== paddingBorder) {
					paddingBorder = newBorder;
					window.SetProperty('Buttons: Padding Border', paddingBorder);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.MODE_FIXED:
			sizeMode = SIZE_MODE.FIXED;
			window.SetProperty('Buttons: Size Mode', sizeMode);
			changed = true;
			break;

		case MENU_ID.MODE_FILL:
			sizeMode = SIZE_MODE.FILL_WIDTH;
			window.SetProperty('Buttons: Size Mode', sizeMode);
			changed = true;
			break;

		case MENU_ID.MODE_FIT_HEIGHT:
			sizeMode = SIZE_MODE.FIT_HEIGHT;
			window.SetProperty('Buttons: Size Mode', sizeMode);
			changed = true;
			break;

		case MENU_ID.COLOR_TOGGLE:
			useTint = !useTint;
			window.SetProperty('Colors: Use Tint', useTint);
			changed = true;
			break;

		case MENU_ID.COLOR_NORMAL: {
			if (useTint) {
				const newColor = utils.ColourPicker(window.ID, colorNormal);
				if (newColor !== -1 && newColor !== colorNormal) {
					colorNormal = newColor;
					window.SetProperty('Colors: Normal', colorNormal);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.COLOR_HOVER: {
			if (useTint) {
				const newColor = utils.ColourPicker(window.ID, colorHover);
				if (newColor !== -1 && newColor !== colorHover) {
					colorHover = newColor;
					window.SetProperty('Colors: Hover', colorHover);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.COLOR_DOWN: {
			if (useTint) {
				const newColor = utils.ColourPicker(window.ID, colorDown);
				if (newColor !== -1 && newColor !== colorDown) {
					colorDown = newColor;
					window.SetProperty('Colors: Down', colorDown);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.BG_TOGGLE:
			useBgColor = !useBgColor;
			window.SetProperty('Colors: Use Background', useBgColor);
			changed = true;
			break;

		case MENU_ID.BG_COLOR: {
			if (useBgColor) {
				const newColor = utils.ColourPicker(window.ID, bgColor);
				if (newColor !== -1 && newColor !== bgColor) {
					bgColor = newColor;
					window.SetProperty('Colors: Background', bgColor);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.RESET:
			// Resets only the CURRENTLY SELECTED style's settings back to defaults —
			// which style is active, and every other style's saved config, are
			// left untouched. The reset values get persisted for this style by the
			// saveStyleConfig() call below (triggered by `changed`).
			_applyConfig(PROP_DEFAULTS);
			window.SetProperty('Buttons: Size',                                        PROP_DEFAULTS.btnSize);
			window.SetProperty('Buttons: Padding Gap',                                 PROP_DEFAULTS.paddingGap);
			window.SetProperty('Buttons: Padding Border',                              PROP_DEFAULTS.paddingBorder);
			window.SetProperty('Buttons: Vertical Alignment (0=Top, 1=Middle, 2=Bottom)', PROP_DEFAULTS.alignV);
			window.SetProperty('Buttons: Horizontal Alignment (0=Left, 1=Centre, 2=Right)', PROP_DEFAULTS.alignH);
			window.SetProperty('Buttons: Size Mode',   PROP_DEFAULTS.sizeMode);
			window.SetProperty('Colors: Use Tint',     PROP_DEFAULTS.useTint);
			window.SetProperty('Colors: Normal',       PROP_DEFAULTS.colorNormal);
			window.SetProperty('Colors: Hover',        PROP_DEFAULTS.colorHover);
			window.SetProperty('Colors: Down',         PROP_DEFAULTS.colorDown);
			window.SetProperty('Colors: Use Background', PROP_DEFAULTS.useBgColor);
			window.SetProperty('Colors: Background',     PROP_DEFAULTS.bgColor);
			changed = true;
			break;

		default:
			if (idx > 0) {
				return panel.rbtn_up(x, y);
			}
			break;
	}

	if (changed) {
		saveStyleConfig(buttonStyle);
		buttons.update();
		window.Repaint();
	}

	return true;
}

function on_colours_changed() {
	panel.colours_changed();
	window.Repaint();
}
