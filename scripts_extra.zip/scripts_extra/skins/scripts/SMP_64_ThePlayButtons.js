'use strict';

window.DefineScript('Playback Buttons Pro', {author:'L.E.D.', options:{grab_focus:false}});

include(fb.ComponentPath + 'samples\\complete\\js\\lodash.min.js');
include(fb.ComponentPath + 'samples\\complete\\js\\helpers.js');
include(fb.ComponentPath + 'samples\\complete\\js\\panel.js');

// ====================== CONSTANTS ======================
const MENU_ID = {
	ALIGN_V_TOP:    10,
	ALIGN_V_MIDDLE: 11,
	ALIGN_V_BOTTOM: 12,
	SIZE_SMALL:     20,
	SIZE_MEDIUM:    21,
	SIZE_LARGE:     22,
	SIZE_XL:        23,
	SIZE_CUSTOM:    24,
	PAD_NONE:       30,
	PAD_STANDARD:   31,
	PAD_WIDE:       32,
	MODE_FIXED:     40,
	MODE_FILL:      41,
	COLOR_TOGGLE:   50,
	COLOR_NORMAL:   51,
	COLOR_HOVER:    52,
	COLOR_DOWN:     53,
	ALIGN_H_LEFT:   60,
	ALIGN_H_CENTER: 61,
	ALIGN_H_RIGHT:  62,
	RESET:          99
};

const SIZE_PRESETS = {
	SMALL:  32,
	MEDIUM: 64,
	LARGE:  128,
	XL:     256
};

const PAD_PRESETS = {
	NONE:     0,
	STANDARD: 10,
	WIDE:     30
};

const ALIGN = {
	TOP:    0,
	MIDDLE: 1,
	BOTTOM: 2,
	LEFT:   0,
	CENTER: 1,
	RIGHT:  2
};

// Default property values defined in one place so reset uses them too.
const PROP_DEFAULTS = {
	btnSize:  128,
	padding:  0,
	alignV:   1,
	alignH:   1,
	fillPanel:   true,
	useTint:     false,
	colorNormal: _RGB(255, 255, 255),
	colorHover:  _RGB(150, 150, 150),
	colorDown:   _RGB(100, 100, 100)
};

// ====================== STATE ======================
let panel = new _panel(true);
let buttons = new _buttons();
let lastPlayState = null;

// Properties
let btnSize, padding, alignV, alignH, fillPanel, useTint;
let colorNormal, colorHover, colorDown;

// ====================== PROPERTY MANAGEMENT ======================
function validateSize(val) {
	const size = parseInt(val, 10);
	return (size >= 16 && size <= 512) ? size : PROP_DEFAULTS.btnSize;
}

function validatePadding(val) {
	const pad = parseInt(val, 10);
	return (pad >= 0 && pad <= 100) ? pad : PROP_DEFAULTS.padding;
}

function validateAlign(val, defaultVal) {
	const def = (defaultVal !== undefined) ? defaultVal : 1;
	return (val >= 0 && val <= 2) ? val : def;
}

function init_properties() {
	btnSize    = validateSize(window.GetProperty('Buttons: Size',
	                 PROP_DEFAULTS.btnSize));
	padding    = validatePadding(window.GetProperty('Buttons: Padding',
	                 PROP_DEFAULTS.padding));
	alignV     = validateAlign(window.GetProperty(
	                 'Buttons: Vertical Alignment (0=Top, 1=Middle, 2=Bottom)',
	                 PROP_DEFAULTS.alignV), PROP_DEFAULTS.alignV);
	alignH     = validateAlign(window.GetProperty(
	                 'Buttons: Horizontal Alignment (0=Left, 1=Centre, 2=Right)',
	                 PROP_DEFAULTS.alignH), PROP_DEFAULTS.alignH);
	fillPanel  = window.GetProperty('Buttons: Fill Panel',  PROP_DEFAULTS.fillPanel);
	useTint    = window.GetProperty('Colors: Use Tint',     PROP_DEFAULTS.useTint);
	colorNormal = window.GetProperty('Colors: Normal', PROP_DEFAULTS.colorNormal);
	colorHover  = window.GetProperty('Colors: Hover',  PROP_DEFAULTS.colorHover);
	colorDown   = window.GetProperty('Colors: Down',   PROP_DEFAULTS.colorDown);
}

init_properties();

// ====================== TINT HELPER ======================
function _tintImage(img, tintColour) {
	if (!img) return null;
	const w = img.Width;
	const h = img.Height;
	const bmp = gdi.CreateImage(w, h);
	const g   = bmp.GetGraphics();
	try {
		g.SetInterpolationMode(7);
		g.DrawImage(img, 0, 0, w, h, 0, 0, w, h, 0, 255);
		const rgb = _toRGB(tintColour);
		g.FillSolidRect(0, 0, w, h, _RGBA(rgb[0], rgb[1], rgb[2], 110));
	} finally {
		bmp.ReleaseGraphics(g);
	}
	return bmp;
}

// ====================== BUTTON DISPOSAL HELPER ======================
function _disposeButton(btn) {
	if (!btn) return;
	// FIX: must call .Dispose() on GDI image objects — setting to null only removes
	// the JS reference; the underlying native GDI bitmap remains allocated until GC
	// which in SMP's SpiderMonkey is unpredictable. Each buttons.update() call
	// leaked one pair of GDI bitmaps when tint was active.
	try { if (btn.img        && btn.img.Dispose)        btn.img.Dispose();        } catch(e) {}
	try { if (btn.img_normal && btn.img_normal.Dispose)  btn.img_normal.Dispose(); } catch(e) {}
	try { if (btn.img_hover  && btn.img_hover.Dispose)   btn.img_hover.Dispose();  } catch(e) {}
	try { if (btn.img_down   && btn.img_down.Dispose)    btn.img_down.Dispose();   } catch(e) {}
	btn.img        = null;
	btn.img_normal = null;
	btn.img_hover  = null;
	btn.img_down   = null;
}

// ====================== BUTTON UPDATE ======================
buttons.update = () => {
	let bsW, bsH, x, y, pad;
	pad = _scale(padding);

	if (fillPanel) {
		// FIX Bug10: was pad*5 — correct is pad*4 (one leading pad + three inter-button gaps).
		bsW = Math.floor((panel.w - (pad * 4)) / 4);
		bsH = _scale(btnSize);
		x   = pad;

		if      (alignV === ALIGN.TOP)    { y = 0; }
		else if (alignV === ALIGN.MIDDLE) { y = Math.floor((panel.h - bsH) / 2); }
		else                              { y = panel.h - bsH; }

	} else {
		// Fixed aspect mode.
		const bs    = _scale(btnSize);
		bsW = bsH   = bs;
		const totalW = (bsW * 4) + (pad * 3);

		if      (alignV === ALIGN.TOP)    { y = 0; }
		else if (alignV === ALIGN.MIDDLE) { y = Math.floor((panel.h - bsH) / 2); }
		else                              { y = panel.h - bsH; }

		if      (alignH === ALIGN.LEFT)   { x = 0; }
		else if (alignH === ALIGN.CENTER) { x = Math.floor((panel.w - totalW) / 2); }
		else                              { x = panel.w - totalW; }
	}

	if (buttons.buttons.stop) {
		_disposeButton(buttons.buttons.stop);
		_disposeButton(buttons.buttons.play);
		_disposeButton(buttons.buttons.previous);
		_disposeButton(buttons.buttons.next);
	}

	const isPlaying = fb.IsPlaying && !fb.IsPaused;

	buttons.buttons.stop     = new _button(x,                    y, bsW, bsH,
	    {normal: 'profile\\buttons\\stop.png'},
	    () => { fb.Stop(); },       'Stop');

	buttons.buttons.play     = new _button(x + (bsW + pad),      y, bsW, bsH,
	    {normal: isPlaying ? 'profile\\buttons\\pause.png' : 'profile\\buttons\\play.png'},
	    () => { fb.PlayOrPause(); }, isPlaying ? 'Pause' : 'Play');

	buttons.buttons.previous = new _button(x + (bsW + pad) * 2,  y, bsW, bsH,
	    {normal: 'profile\\buttons\\previous.png'},
	    () => { fb.Prev(); },       'Previous');

	buttons.buttons.next     = new _button(x + (bsW + pad) * 3,  y, bsW, bsH,
	    {normal: 'profile\\buttons\\next.png'},
	    () => { fb.Next(); },       'Next');

	if (useTint) {
		_.forEach(buttons.buttons, (btn) => {
			if (!btn) return;
			// FIX Bug13: apply all three colour states including colorDown (img_down).
			btn.img_normal = _tintImage(btn.img_normal, colorNormal);
			btn.img_hover  = _tintImage(btn.img_hover  || btn.img_normal, colorHover);
			btn.img_down   = _tintImage(btn.img_normal, colorDown);
			btn.img = btn.img_normal;
		});
	}

	lastPlayState = isPlaying;
};

// ====================== CALLBACKS ======================
function on_size() {
	panel.size();
	buttons.update();
}

function on_paint(gr) {
	panel.paint(gr);
	buttons.paint(gr);
}

function on_playback_stop() {
	buttons.update();
	window.Repaint();
}

function on_playback_pause() {
	const isPaused = fb.IsPaused;
	if (lastPlayState !== !isPaused) {
		buttons.update();
		window.Repaint();
	}
}

function on_playback_starting() {
	if (lastPlayState !== true) {
		buttons.update();
		window.Repaint();
	}
}

function on_mouse_move(x, y) {
	buttons.move(x, y);
}

function on_mouse_leave() {
	buttons.leave();
}

function on_mouse_lbtn_up(x, y, mask) {
	buttons.lbtn_up(x, y, mask);
}

function on_script_unload() {
	// Dispose all button GDI images.
	if (buttons.buttons) {
		_.forEach(buttons.buttons, (btn) => { _disposeButton(btn); });
	}
	// FIX Bug9: guard _tt with typeof in case helpers.js version doesn't define it.
	if (typeof _tt === 'function') _tt('');
	// FIX Bug8: guard _gr before passing to ReleaseGraphics — _gr may be null if
	// it was never initialised or was already released.
	if (_bmp) {
		if (_gr) { try { _bmp.ReleaseGraphics(_gr); } catch(e) {} }
		try { _bmp.Dispose(); } catch(e) {}
	}
	_gr  = null;
	_bmp = null;
}

// ====================== MENU ======================
function on_mouse_rbtn_up(x, y) {
	const m   = window.CreatePopupMenu();
	const v   = window.CreatePopupMenu();
	const h   = window.CreatePopupMenu();
	const s   = window.CreatePopupMenu();
	const p   = window.CreatePopupMenu();
	const col = window.CreatePopupMenu();

	// Mode selection
	m.AppendMenuItem(MF_STRING, MENU_ID.MODE_FIXED, 'Fixed (Maintain Aspect)');
	m.AppendMenuItem(MF_STRING, MENU_ID.MODE_FILL,  'Fill Width (Stretch)');
	m.CheckMenuRadioItem(MENU_ID.MODE_FIXED, MENU_ID.MODE_FILL,
	    fillPanel ? MENU_ID.MODE_FILL : MENU_ID.MODE_FIXED);
	m.AppendMenuSeparator();

	// Horizontal alignment (grayed in fill mode)
	h.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_H_LEFT,   'Left');
	h.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_H_CENTER, 'Centre');
	h.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_H_RIGHT,  'Right');
	h.CheckMenuRadioItem(MENU_ID.ALIGN_H_LEFT, MENU_ID.ALIGN_H_RIGHT,
	    MENU_ID.ALIGN_H_LEFT + alignH);
	h.AppendTo(m, fillPanel ? MF_GRAYED : MF_STRING, 'Horizontal Alignment');

	// Vertical alignment
	v.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_V_TOP,    'Top');
	v.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_V_MIDDLE, 'Middle');
	v.AppendMenuItem(MF_STRING, MENU_ID.ALIGN_V_BOTTOM, 'Bottom');
	v.CheckMenuRadioItem(MENU_ID.ALIGN_V_TOP, MENU_ID.ALIGN_V_BOTTOM,
	    MENU_ID.ALIGN_V_TOP + alignV);
	v.AppendTo(m, MF_STRING, 'Vertical Alignment');
	m.AppendMenuSeparator();

	// Button size
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_SMALL,  `Small (${SIZE_PRESETS.SMALL})`);
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_MEDIUM, `Medium (${SIZE_PRESETS.MEDIUM})`);
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_LARGE,  `Large (${SIZE_PRESETS.LARGE})`);
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_XL,     `Extra Large (${SIZE_PRESETS.XL})`);
	s.AppendMenuSeparator();
	s.AppendMenuItem(MF_STRING, MENU_ID.SIZE_CUSTOM, 'Set Custom Size...');
	s.AppendTo(m, MF_STRING, 'Button Size');

	// Padding
	p.AppendMenuItem(MF_STRING, MENU_ID.PAD_NONE,     `None (${PAD_PRESETS.NONE})`);
	p.AppendMenuItem(MF_STRING, MENU_ID.PAD_STANDARD, `Standard (${PAD_PRESETS.STANDARD})`);
	p.AppendMenuItem(MF_STRING, MENU_ID.PAD_WIDE,     `Wide (${PAD_PRESETS.WIDE})`);
	p.AppendTo(m, MF_STRING, 'Padding');

	// Colors & Tint
	col.AppendMenuItem(MF_STRING, MENU_ID.COLOR_TOGGLE, 'Enable Custom Tint');
	col.CheckMenuItem(MENU_ID.COLOR_TOGGLE, useTint);
	col.AppendMenuSeparator();
	col.AppendMenuItem(useTint ? MF_STRING : MF_GRAYED, MENU_ID.COLOR_NORMAL, 'Set Normal Color...');
	col.AppendMenuItem(useTint ? MF_STRING : MF_GRAYED, MENU_ID.COLOR_HOVER,  'Set Hover Color...');
	col.AppendMenuItem(useTint ? MF_STRING : MF_GRAYED, MENU_ID.COLOR_DOWN,   'Set Click Color...');
	col.AppendTo(m, MF_STRING, 'Colors & Tint');

	m.AppendMenuSeparator();
	m.AppendMenuItem(MF_STRING, MENU_ID.RESET, 'Reset All Settings');

	const idx = m.TrackPopupMenu(x, y);
	let changed = false;

	switch (idx) {
		case MENU_ID.ALIGN_V_TOP:
		case MENU_ID.ALIGN_V_MIDDLE:
		case MENU_ID.ALIGN_V_BOTTOM:
			alignV = idx - MENU_ID.ALIGN_V_TOP;
			window.SetProperty('Buttons: Vertical Alignment (0=Top, 1=Middle, 2=Bottom)', alignV);
			changed = true;
			break;

		case MENU_ID.ALIGN_H_LEFT:
		case MENU_ID.ALIGN_H_CENTER:
		case MENU_ID.ALIGN_H_RIGHT:
			if (!fillPanel) {
				alignH = idx - MENU_ID.ALIGN_H_LEFT;
				window.SetProperty('Buttons: Horizontal Alignment (0=Left, 1=Centre, 2=Right)', alignH);
				changed = true;
			}
			break;

		case MENU_ID.SIZE_SMALL:
			btnSize = SIZE_PRESETS.SMALL;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_MEDIUM:
			btnSize = SIZE_PRESETS.MEDIUM;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_LARGE:
			btnSize = SIZE_PRESETS.LARGE;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_XL:
			btnSize = SIZE_PRESETS.XL;
			window.SetProperty('Buttons: Size', btnSize);
			changed = true;
			break;

		case MENU_ID.SIZE_CUSTOM: {  // braces needed — declares local consts
			const val = utils.InputBox(window.ID,
			    'Enter button size (16-512 pixels):', 'Custom Size', btnSize);
			if (val) {
				const newSize = validateSize(val);
				if (newSize !== btnSize) {
					btnSize = newSize;
					window.SetProperty('Buttons: Size', btnSize);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.PAD_NONE:
			padding = PAD_PRESETS.NONE;
			window.SetProperty('Buttons: Padding', padding);
			changed = true;
			break;

		case MENU_ID.PAD_STANDARD:
			padding = PAD_PRESETS.STANDARD;
			window.SetProperty('Buttons: Padding', padding);
			changed = true;
			break;

		case MENU_ID.PAD_WIDE:
			padding = PAD_PRESETS.WIDE;
			window.SetProperty('Buttons: Padding', padding);
			changed = true;
			break;

		case MENU_ID.MODE_FIXED:
			fillPanel = false;
			window.SetProperty('Buttons: Fill Panel', false);
			changed = true;
			break;

		case MENU_ID.MODE_FILL:
			fillPanel = true;
			window.SetProperty('Buttons: Fill Panel', true);
			changed = true;
			break;

		case MENU_ID.COLOR_TOGGLE:
			useTint = !useTint;
			window.SetProperty('Colors: Use Tint', useTint);
			changed = true;
			break;

		case MENU_ID.COLOR_NORMAL: {
			if (useTint) {
				const newColor = utils.ColourPicker(window.ID, colorNormal);
				if (newColor !== -1 && newColor !== colorNormal) {
					colorNormal = newColor;
					window.SetProperty('Colors: Normal', colorNormal);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.COLOR_HOVER: {
			if (useTint) {
				const newColor = utils.ColourPicker(window.ID, colorHover);
				if (newColor !== -1 && newColor !== colorHover) {
					colorHover = newColor;
					window.SetProperty('Colors: Hover', colorHover);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.COLOR_DOWN: {
			if (useTint) {
				const newColor = utils.ColourPicker(window.ID, colorDown);
				if (newColor !== -1 && newColor !== colorDown) {
					colorDown = newColor;
					window.SetProperty('Colors: Down', colorDown);
					changed = true;
				}
			}
			break;
		}

		case MENU_ID.RESET:
			// defaults makes the stored state consistent with what is displayed.
			window.SetProperty('Buttons: Size',                                        PROP_DEFAULTS.btnSize);
			window.SetProperty('Buttons: Padding',                                     PROP_DEFAULTS.padding);
			window.SetProperty('Buttons: Vertical Alignment (0=Top, 1=Middle, 2=Bottom)', PROP_DEFAULTS.alignV);
			window.SetProperty('Buttons: Horizontal Alignment (0=Left, 1=Centre, 2=Right)', PROP_DEFAULTS.alignH);
			window.SetProperty('Buttons: Fill Panel',  PROP_DEFAULTS.fillPanel);
			window.SetProperty('Colors: Use Tint',     PROP_DEFAULTS.useTint);
			window.SetProperty('Colors: Normal',       PROP_DEFAULTS.colorNormal);
			window.SetProperty('Colors: Hover',        PROP_DEFAULTS.colorHover);
			window.SetProperty('Colors: Down',         PROP_DEFAULTS.colorDown);
			init_properties();
			changed = true;
			break;

		default:
			if (idx > 0) {
				return panel.rbtn_up(x, y);
			}
			break;
	}

	if (changed) {
		buttons.update();
		window.Repaint();
	}

	return true;
}

function on_colours_changed() {
	panel.colours_changed();
	window.Repaint();
}
